public class GeoLocation {

    private final double latitude;

    private final double longitude;

    public GeoLocation(double latitude, double longitude) {

    }

    public double getLatitude() {

    }

    public double getLongitude() {

    }

    public double getDistance(GeoLocation end) {

    }

    public static double getDistance(GeoLocation start, GeoLocation end) {

    }

}