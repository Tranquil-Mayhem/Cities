public class ConsoleUtil {
    public static int getInteger(String prompt) {

    }

    public static int getInteger(String prompt, int min, int max) {

    }

    public static int getString(String prompt) {

    }
}
