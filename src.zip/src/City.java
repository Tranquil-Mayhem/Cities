public class City {

    private final String name;

    private final GeoLocation location;

    public final long id;

    public City(String name, GeoLocation location) {

    }

    public String getName() {

    }

    public long getId() {

    }

    public GeoLocation getLocation() {

    }

    public static City parse(String line) {

    }

    public double distance(City end) {

    }

    public static double distance(City start, City end) {

    }
}