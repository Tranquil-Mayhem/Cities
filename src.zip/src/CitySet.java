import java.util.Set;

public class CitySet {
    private final Set<City> cities;

    public CitySet(boolean hasOrder) {

    }

    public void add(City city) {

    }

    public boolean contains(City city) {

    }

    public CitySet nClosestCities(City origin, int nValue) {

    }

    public CitySet nFurthestCities(City origin, int nValue) {

    }

    public CitySet withinRadius(City center, double radius) {
        
    }
}