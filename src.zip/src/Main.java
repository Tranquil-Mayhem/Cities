import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        var cityList = new CityList();

        // NOTE the uscities.csv file must be placed in your project folder OUTSIDE of the src folder.
        try (var input = new Scanner(new BufferedReader(new FileReader("uscities.csv")))) {
            while (input.hasNextLine()) {
                cityList.add(City.parse(input.nextLine()));
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }

        // Ask the user for a city by name or id. If the Name or id matches, then
        // ask for a number between 1 and 20 and display the number of closest and furthest cities

        // Next, ask the user radius and find all the cities within the circle using the previous
        // city as the center.
    }
}